//
//  Administrator.swift
//  MAD3004_Project
//
//  Created by Guneet Singh Lamba on 03/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import Foundation

class Administrator {
 
    var AdminName:String?
    var email:String?
    
    
    func updateCatalog() -> Bool {
        
        
    return true
    
    }
    




}
