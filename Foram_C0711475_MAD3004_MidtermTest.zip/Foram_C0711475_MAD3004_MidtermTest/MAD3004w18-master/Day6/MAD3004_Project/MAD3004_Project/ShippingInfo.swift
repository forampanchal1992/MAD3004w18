//
//  ShippingInfo.swift
//  MAD3004_Project
//
//  Created by Guneet Singh Lamba on 03/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import Foundation

class ShippingInfo{
    
    
    var shippingId: Int = 1
    var shippingType:String = "Regular"
    var shippingCost:Int = 250
    var shippingRegionId:Int = 1
    
    func shippingDetails() {
        print(shippingId)
        print(shippingType)
        print(shippingCost)
        print(shippingRegionId)
        
    }
    
    func updateShippingInfo() {
        
        }
    
    
    
    
    
}
