//
//  main.swift
//  TaskDay7
//
//  Created by MacStudent on 2018-02-06.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello world")

let a = 33.prime
print(a.primenum(33))
